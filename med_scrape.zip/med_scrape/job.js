const XLSX = require("xlsx");

// ===============================
// JOOBLE API CONFIGURATION
// ===============================
const API_KEY = "49c00f54-ad96-41b9-be4f-936f8a542e51";
const API_URL = `https://jooble.org/api/${API_KEY}`;

const LOCATION = "ireland";
const RESULTS_PER_PAGE = 20;
const TOTAL_REQUESTS = 50;

// ===============================
// MEDICAL JOB KEYWORDS
// ===============================
const keywords = [
    "Doctor",
    "Nurse",
    "Pharmacist",
    "Medical Laboratory Scientist",
    "Radiographer",
    "Dentist",
    "Physiotherapist",
    "Medical Officer",
    "Healthcare Assistant",
    "Health Technician"
];

// ===============================
// SEARCH JOOBLE
// ===============================
async function searchJobs(keyword, page) {

    const response = await fetch(API_URL, {
        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({
            keywords: keyword,
            location: LOCATION,
            page: page,
            ResultOnPage: RESULTS_PER_PAGE,
            companysearch: false
        })
    });

    if (!response.ok) {
        const errorText = await response.text();

        throw new Error(
            `HTTP ${response.status} - ${response.statusText}\n${errorText}`
        );
    }

    return await response.json();
}

// ===============================
// MAIN PROGRAM
// ===============================
async function main() {

    if (!API_KEY || API_KEY === "YOUR_JOOBLE_API_KEY_HERE") {
        console.log("ERROR: Please put your Jooble API key in the API_KEY variable.");
        return;
    }

    let allJobs = [];
    let requestCount = 0;

    for (const keyword of keywords) {

        if (requestCount >= TOTAL_REQUESTS) {
            break;
        }

        let page = 1;

        while (requestCount < TOTAL_REQUESTS) {

            console.log(
                `Searching "${keyword}" - Page ${page}`
            );

            try {

                const data = await searchJobs(keyword, page);

                requestCount++;

                if (!data.jobs || data.jobs.length === 0) {
                    console.log("No more jobs found.");
                    break;
                }

                console.log(
                    `Found ${data.jobs.length} jobs`
                );

                for (const job of data.jobs) {

                    allJobs.push({
                        Keyword: keyword,
                        Title: job.title || "",
                        Company: job.company || "",
                        Location: job.location || "",
                        Salary: job.salary || "",
                        Type: job.type || "",
                        Source: job.source || "",
                        Link: job.link || "",
                        Updated: job.updated || "",
                        Description: job.snippet || ""
                    });
                }

                page++;

            } catch (error) {

                requestCount++;

                console.log(
                    `API request failed for "${keyword}" page ${page}:`
                );

                console.log(error.message);

                break;
            }
        }
    }

    // ===============================
    // REMOVE DUPLICATES
    // ===============================
    const uniqueJobs = [];

    const seen = new Set();

    for (const job of allJobs) {

        const identifier =
            `${job.Title}|${job.Company}|${job.Location}|${job.Link}`;

        if (!seen.has(identifier)) {

            seen.add(identifier);
            uniqueJobs.push(job);
        }
    }

    // ===============================
    // EXPORT TO EXCEL
    // ===============================
    if (uniqueJobs.length > 0) {

        const worksheet =
            XLSX.utils.json_to_sheet(uniqueJobs);

        const workbook =
            XLSX.utils.book_new();

        XLSX.utils.book_append_sheet(
            workbook,
            worksheet,
            "Medical Jobs"
        );

        XLSX.writeFile(
            workbook,
            "medicals_healthcare_job_ireland.xlsx"
        );

        console.log("\n================================");
        console.log("EXCEL FILE CREATED SUCCESSFULLY");
        console.log("================================");
        console.log(`Total unique jobs: ${uniqueJobs.length}`);
        console.log("File: medical_healthcare_jobs.xlsx");

    } else {

        console.log("\nNo jobs were collected.");
    }

    console.log(`API requests used: ${requestCount}`);
}

// ===============================
// RUN PROGRAM
// ===============================
main();